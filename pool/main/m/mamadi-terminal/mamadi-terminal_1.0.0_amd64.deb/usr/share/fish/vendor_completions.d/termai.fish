# fish completion for termai. Installed by the package to
# /usr/share/fish/vendor_completions.d/termai.fish, or sourced manually.
complete -c termai -f
complete -c termai -n '__fish_use_subcommand' -a setup -d 'Configure your own provider and key'
complete -c termai -n '__fish_use_subcommand' -a doctor -d 'Check configuration'
complete -c termai -n '__fish_use_subcommand' -a completions -d 'Print shell completions'
complete -c termai -l help -d 'Show help'
complete -c termai -l version -d 'Show version'
complete -c termai -l dry-run -d 'Show plan without running it'
complete -c termai -l yes -d 'Skip confirmation'
complete -c termai -l print -d 'Print only the first command, for eval in any shell'
