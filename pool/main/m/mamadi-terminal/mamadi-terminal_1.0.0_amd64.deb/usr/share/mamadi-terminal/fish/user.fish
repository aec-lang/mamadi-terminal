# Mamadi's fish overrides - put at: ~/.config/fish/user.fish
# Ryoku's config.fish loads this file LAST, so this wins over
# Ryoku's defaults.

# Suggestion in a light, faded blue - Ryoku's own light blue (#8AA9CC).
# If you want it even lighter / more cyan, use 93D4E0 instead.
set -g fish_color_autosuggestion 8AA9CC

# --- Icons + color: eza (ls with icons) and bat (cat with colors) ---
# Ryoku already aliases ls to eza when eza is installed. These add the rest.
if command -q eza
    alias ll 'eza -lh --group-directories-first --icons=auto'
    alias tree 'eza --tree --icons=auto'
end
# On Ubuntu/Debian the bat binary is called batcat, not bat.
if command -q batcat
    alias cat 'batcat --paging=never'
    alias bat 'batcat'
else if command -q bat
    alias cat 'bat --paging=never'
end

# Colorful prompt: starship is already started by Ryoku's config.fish
# when starship is installed. Its own config lives at ~/.config/starship.toml
